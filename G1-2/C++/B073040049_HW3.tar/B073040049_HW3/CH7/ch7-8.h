#include <iostream>
#include <vector>

using namespace std;

class classOfScore{
	private:
		vector<int> scores;
	public:
		classOfScore();
		void Input();
		void Output();
	
};