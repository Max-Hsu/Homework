#include <iostream>

using namespace std;

class weight{
	public:
	void setWeightPounds(float Pounds);
	void setWeightKilograms(float Kilograms);
	void setWeightOunces(float Ounces);
	void PrintIt();
	private:
	float weightInPound;
	
};