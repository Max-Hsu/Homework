#include <iostream>
#include "g.h"

namespace A{
	using std::cout;
	void g(){
		cout<<"Function G is called\n";
	}
}