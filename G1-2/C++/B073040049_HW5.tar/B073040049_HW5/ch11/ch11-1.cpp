#include <iostream>
#include "f.h"
#include "g.h"
using A::f;
using A::g;

int main(){
	f();
	g();
	return 0;
}