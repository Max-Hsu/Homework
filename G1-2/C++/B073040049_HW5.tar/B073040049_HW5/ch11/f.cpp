#include <iostream>
#include "f.h"

namespace A{
	using std::cout;
	void f(){
		cout<<"Function F is called\n";
	}
}