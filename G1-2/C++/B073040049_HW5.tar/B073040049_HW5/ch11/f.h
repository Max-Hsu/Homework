#include <iostream>
#ifndef F
#define F
namespace A{
	using std::cout;
	void f();
}
#endif