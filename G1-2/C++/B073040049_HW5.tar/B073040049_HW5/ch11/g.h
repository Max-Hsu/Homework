#include <iostream>

#ifndef G
#define G
namespace A{
	using std::cout;
	void g();
}
#endif