#include <iostream>

using namespace std;

int main(){
int mgram;
cout<<"please input milligrams of drink:";
cin>>mgram;
cout<<"It would take "<<10000/mgram<<" cup to kill you"<<endl;

return 0;
}