#include <stdio.h>
#include <stdlib.h>

int main()
{
    hello();
    printf("Hello world!\n");
    return 0;
}
