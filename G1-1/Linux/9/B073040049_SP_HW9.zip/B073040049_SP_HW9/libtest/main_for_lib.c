#include <stdio.h>
#include <stdlib.h>
void hello(){
printf("hello\n");
}
