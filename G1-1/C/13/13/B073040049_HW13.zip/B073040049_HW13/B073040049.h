#ifndef B073040049_H_INCLUDED
#define B073040049_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
void mysort(int array_file[],int num_of_file);
int myBinarySearch(int array_file[],int target,int head,int tail);

#endif // B073040049_H_INCLUDED
